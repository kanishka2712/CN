#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>

const int SERVER_PORT = 12345;

struct DNSRecord {
    char domain[256];
    char ip[256];
};

struct DNSRecord dnsTable[] = {
    {"google.com", "172.217.168.46"},
    {"vikhram.com", "192.155.155.155"},
    {"ananth.in", "122.19.05.203"},
    {"hacker.com","154.101.102.103"}
};

void handleClientRequest(int clientSock, const char* domain, struct sockaddr_in clientAddr) {
    char ip[256] = "IP not found";

    for (int i = 0; i < sizeof(dnsTable) / sizeof(dnsTable[0]); i++) {
        if (strcmp(dnsTable[i].domain, domain) == 0) {
            strcpy(ip, dnsTable[i].ip);
            break;
        }
    }

    sendto(clientSock, ip, strlen(ip), 0, (struct sockaddr*)&clientAddr, sizeof(clientAddr));
}

int main() {
    int sockfd;
    struct sockaddr_in serverAddr;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Error opening socket");
        return 1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error binding socket");
        return 1;
    }

    while (1) {
        struct sockaddr_in clientAddr;
        socklen_t clientAddrLen = sizeof(clientAddr);

        char buffer[256];
        memset(buffer, 0, sizeof(buffer));

        int bytesReceived = recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr*)&clientAddr, &clientAddrLen);
        if (bytesReceived < 0) {
            perror("Error receiving data");
            continue;
        }

        if (fork() == 0) {
            handleClientRequest(sockfd, buffer, clientAddr);
            exit(0);
        }
    }

    close(sockfd);

    return 0;
}

