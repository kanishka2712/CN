#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

const int SERVER_PORT = 12345; // Port of the DNS server

int main() {
    int client_socket;
    struct sockaddr_in server_addr;

    client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket < 0) {
        perror("Error creating socket");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    char query[256];

    while (1) {
        printf("Enter a domain name: ");
        scanf("%s", query);
        
         if (strcmp(query, "quit") == 0) {
            // User wants to quit
            break;
        }

        // Send the DNS query to the server
        sendto(client_socket, query, strlen(query), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));

        char response[256];

        // Receive the IP address response from the server
        int bytes_received = recvfrom(client_socket, response, sizeof(response), 0, NULL, NULL);
        if (bytes_received < 0) {
            perror("Error receiving data");
            exit(1);
        }

        response[bytes_received] = '\0';

        printf("IP Address: %s\n", response);
    }

    close(client_socket);
    return 0;
}

