#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>

#define PORT 8080
#define MAX_BUFFER_SIZE 8192

void handle_request(int client_socket) {
    // Open and read the contents of the HTML file
    int file_fd = open("index.html", O_RDONLY);
    if (file_fd == -1) {
        perror("Error opening HTML file");
        exit(EXIT_FAILURE);
    }

    // Read the HTML file content into a buffer
    char buffer[MAX_BUFFER_SIZE];
    ssize_t bytesRead = read(file_fd, buffer, sizeof(buffer));
    close(file_fd);

    // Prepare the HTTP response with HTML content
    char response[MAX_BUFFER_SIZE];
    snprintf(response, sizeof(response), "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: %zd\r\n\r\n%s", bytesRead, buffer);

    // Send the response to the client
    send(client_socket, response, strlen(response), 0);
    close(client_socket);
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
        perror("Setsockopt failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Waiting for connections...\n");

    while (1) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("Accept failed");
            exit(EXIT_FAILURE);
        }

        printf("Connection accepted\n");
        handle_request(new_socket);
        printf("Response sent\n");

        close(new_socket);
        printf("Connection closed\n");
    }

    return 0;
}

