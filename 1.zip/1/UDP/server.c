#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 1234
#define MAX_LEN 256

int main() {
    int server_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char message[MAX_LEN];

    // Creating socket
    server_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_socket == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initializing server structures
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Binding socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Binding failed");
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on PORT %d....\n", PORT);

    // Receiving and sending messages
    while (1) {
        int bytes_received = recvfrom(server_socket, message, sizeof(message), 0, (struct sockaddr *)&client_addr, &client_addr_len);
        if (bytes_received <= 0) {
            printf("Connection closed\n");
            break;
        }
        message[bytes_received] = '\0';
        printf("Client: %s\n", message);
        printf("Server: ");
        fgets(message, sizeof(message), stdin);
        sendto(server_socket, message, strlen(message), 0, (struct sockaddr *)&client_addr, client_addr_len);
    }

    close(server_socket);
    return 0;
}

