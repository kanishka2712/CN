#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 1234
#define IP "127.0.0.1"
#define MAX_LEN 256

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char message[MAX_LEN];

    // Creating socket
    client_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_socket == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initializing server structures
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(IP);
    server_addr.sin_port = htons(PORT);

    // Getting requests and sending messages
    while (1) {
        printf("Client: ");
        fgets(message, sizeof(message), stdin);
        sendto(client_socket, message, strlen(message), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));

        int bytes_received = recvfrom(client_socket, message, sizeof(message), 0, NULL, NULL);
        if (bytes_received <= 0) {
            printf("Connection closed\n");
            break;
        }
        message[bytes_received] = '\0';
        printf("Server: %s\n", message);
    }

    close(client_socket);
    return 0;
}

