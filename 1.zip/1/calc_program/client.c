#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<sys/types.h>


#define PORT 8080
#define MAXSIZE 1024
#define SERVER_IP "127.0.0.1"

int main(){

	int client_fd;
	char buffer[MAXSIZE];
	struct sockaddr_in servaddr;
	
	socklen_t len;
	
	if((client_fd = socket(AF_INET, SOCK_STREAM, 0 )) < 0){
		perror("SOcket creation failed");
		exit(EXIT_FAILURE);
	}
	
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(PORT);
	servaddr.sin_addr.s_addr = inet_addr(SERVER_IP);
	
	if(connect(client_fd, (struct sockaddr*)&servaddr,sizeof(servaddr)) < 0){
		perror("Connection failed");
		exit(EXIT_FAILURE);
	}
	
	while(1){
	
		printf("Menu\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Date and time\n6.Exit\n\n");
		int choice;
		printf("Enter the choice: ");
		scanf("%d",&choice);
		
		if( choice == 6 ){
			close(client_fd);
			exit(0);
		}else if( choice == 5 ){
			send(client_fd, "datetime", strlen("datetime"), 0);
		}else if( choice >= 1 && choice<=4 ){
			char opr;
			double op1, op2;
			if(choice == 1){
				opr = '+';
			}else if(choice == 2){
				opr = '-';
			}else if(choice == 3){
				opr = '*';
			}else{
				opr = '/';
			}
			
			printf("Enter 2 no.'s : ");
			scanf("%lf %lf",&op1, &op2);
			sprintf(buffer, "%c %lf %lf", opr, op1, op2);
			send(client_fd, buffer, strlen(buffer), 0);
			
		}
	
		memset(buffer, 0, sizeof(buffer));
		
		int n = recv(client_fd, buffer, MAXSIZE, 0);
		if( n <= 0 ){
			printf("Closed\n");
			break;
		}
		buffer[n]='\0';
		
		printf("Server : %s\n\n",buffer);
	
	}
	
	close(client_fd);
	return 0;

}

