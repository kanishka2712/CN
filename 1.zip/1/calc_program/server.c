#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<time.h>


#define PORT 8080
#define MAXSIZE 1024

double operations(char opr, double op1, double op2){
	switch(opr){
	
		case('+'):
			return op1 + op2;
			break;
		case('-'):
			return op1 - op2;
			break;
		case('*'):
			return op1 * op2;
			break;
		case('/'):
			return op1 / op2;
			break;
		default:
			return 1.0;
			break; 
	
	}
}

int main(){

	int server_fd, client_fd;
	char buffer[MAXSIZE];
	struct sockaddr_in servaddr, cliaddr;
	
	socklen_t len;
	
	if((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
		perror("socket creation failed\n");
		exit(EXIT_FAILURE);
	}
	
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(PORT);
	servaddr.sin_addr.s_addr = INADDR_ANY;
	
	if(bind(server_fd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0){
		perror("Bind failed\n");
		exit(EXIT_FAILURE);
	}
	
	if(listen(server_fd, 5) < 0){
		perror("Listen failed");
		exit(EXIT_FAILURE);
	}
	
	if((client_fd = accept(server_fd, (struct sockaddr*)&cliaddr, &len)) < 0){
		perror("Accept failed\n");
		exit(EXIT_FAILURE);
	}
	
	printf("Server is ready...\n");
	
	while(1){
		
		int n = recv(client_fd, buffer, MAXSIZE, 0);
		if(n <= 0){
			printf("Closed\n");
			break;
		}
		buffer[n] = '\0';
		
		if(strcmp(buffer, "datetime") == 0){
			time_t cur_time;
			time(&cur_time);
			char *time_str = ctime(&cur_time);
			send(client_fd, time_str, strlen(time_str), 0);
		}else{
			char opr;
			double op1, op2;
			sscanf(buffer, "%c %lf %lf", &opr, &op1, &op2);
			double result = operations(opr, op1, op2);
			sprintf(buffer, "%.2lf", result);		
			send(client_fd, buffer, sizeof(buffer), 0);
		}
		
	}
	
	close(server_fd);
	close(client_fd);
	return 0;

}

