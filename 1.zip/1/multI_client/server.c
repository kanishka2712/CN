#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024

int main() {
    int server_fd, client_sockets[MAX_CLIENTS], max_clients = MAX_CLIENTS, activity, max_sd, sd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Create a socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize server address structure
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(12345);

    // Bind the socket
    if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 5) == -1) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    // Initialize client sockets array
    for (int i = 0; i < max_clients; i++) {
        client_sockets[i] = 0;
    }

    printf("Chat server is running on port 12345\n");

    while (1) {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        FD_SET(server_fd, &read_fds);
        max_sd = server_fd;

        for (int i = 0; i < max_clients; i++) {
            sd = client_sockets[i];

            if (sd > 0) {
                FD_SET(sd, &read_fds);
            }

            if (sd > max_sd) {
                max_sd = sd;
            }
        }

        activity = select(max_sd + 1, &read_fds, NULL, NULL, NULL);

        if (activity == -1) {
            perror("Select error");
        }

        // New connection
        if (FD_ISSET(server_fd, &read_fds)) {
            int new_socket;
            if ((new_socket = accept(server_fd, NULL, NULL)) == -1) {
                perror("Accept failed");
                exit(EXIT_FAILURE);
            }

            printf("New client connected, socket fd is %d\n", new_socket);

            // Add new connection to the list of clients
            for (int i = 0; i < max_clients; i++) {
                if (client_sockets[i] == 0) {
                    client_sockets[i] = new_socket;
                    printf("Client %d connected\n", i + 1);
                    break;
                }
            }
        }

        // Check for data from clients
        for (int i = 0; i < max_clients; i++) {
            sd = client_sockets[i];
            if (FD_ISSET(sd, &read_fds)) {
                int valread;
                if ((valread = read(sd, buffer, BUFFER_SIZE)) == 0) {
                    // Disconnect client
                    getpeername(sd, (struct sockaddr*)&server_addr, (socklen_t*)&server_addr);
                    printf("Client %d disconnected\n", i + 1);
                    close(sd);
                    client_sockets[i] = 0;
                } else {
                    buffer[valread] = '\0';
                    printf("Client %d: %s", i + 1, buffer);

                    // Reply to the specific client
                    char reply[BUFFER_SIZE];
                    //sprintf(reply, "Server: Message received from Client %d\n", i + 1);
                    fgets(reply, sizeof(reply), stdin);
                    send(sd, reply, strlen(reply), 0);
                    //fgets(reply, sizeof(reply), stdin);
                 
                }
            }
        }
    }

    return 0;
}


