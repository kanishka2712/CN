#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define PACKET_SIZE 64
#define MAX_HOPS 30

// Checksum calculation for ICMP packet
unsigned short calculate_checksum(unsigned short *ptr, int length) {
    unsigned long sum = 0;
    unsigned short checksum;

    while (length > 1) {
        sum += *ptr++;
        length -= 2;
    }

    if (length == 1) {
        sum += (unsigned short)(*(unsigned char *)ptr);
    }

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    checksum = (unsigned short)(~sum);

    return checksum;
}

// Send an ICMP Echo Request packet
void send_ping(int sockfd, struct sockaddr_in *dest_addr, int seq) {
    char packet[PACKET_SIZE];
    struct icmphdr *icmp_header = (struct icmphdr *)packet;

    memset(packet, 0, PACKET_SIZE);

    // Set up the ICMP header
    icmp_header->type = ICMP_ECHO;
    icmp_header->code = 0;
    icmp_header->un.echo.id = 0;
    icmp_header->un.echo.sequence = seq;
    icmp_header->checksum = 0;
    icmp_header->checksum = calculate_checksum((unsigned short *)icmp_header, PACKET_SIZE);

    // Send the ICMP packet
    sendto(sockfd, packet, PACKET_SIZE, 0, (struct sockaddr *)dest_addr, sizeof(struct sockaddr_in));
}

// Receive and process an ICMP Echo Reply
void receive_ping(int sockfd, int seq) {
    char packet[PACKET_SIZE];
    struct sockaddr_in sender_addr;
    socklen_t sender_addr_len = sizeof(sender_addr);

    if (recvfrom(sockfd, packet, PACKET_SIZE, 0, (struct sockaddr *)&sender_addr, &sender_addr_len) < 0) {
        printf("Timeout\n");
    } else {
        // Calculate and print the round-trip time (RTT)
        struct icmphdr *icmp_header = (struct icmphdr *)packet;
        struct timespec *send_time = (struct timespec *)(packet + sizeof(struct icmphdr));

        struct timespec recv_time;
        clock_gettime(CLOCK_MONOTONIC, &recv_time);

        long rtt = (recv_time.tv_nsec - send_time->tv_nsec) / 1000000;
        printf("%d bytes from %s: icmp_seq=%d ttl=%d time=%ld ms\n", PACKET_SIZE, inet_ntoa(sender_addr.sin_addr), seq, icmp_header->un.echo.id, rtt);
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <hostname or IP>\n", argv[0]);
        exit(1);
    }

    char *hostname = argv[1];

    struct addrinfo hints, *res;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;

    if (getaddrinfo(hostname, NULL, &hints, &res) != 0) {
        perror("Error in getaddrinfo");
        exit(1);
    }

    char ip_address[INET_ADDRSTRLEN];
    struct sockaddr_in *dest_addr = (struct sockaddr_in *)res->ai_addr;
    inet_ntop(AF_INET, &(dest_addr->sin_addr), ip_address, INET_ADDRSTRLEN);
    
    printf("PING %s (%s) %d bytes\n", hostname, ip_address, PACKET_SIZE);

    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sockfd < 0) {
        perror("Error in socket");
        exit(1);
    }

    int seq = 1;
    int hops = 0;

    while (hops < MAX_HOPS) {
        send_ping(sockfd, dest_addr, seq);
        receive_ping(sockfd, seq);

        seq++;
        hops++;
        sleep(1);  // Wait before sending the next ICMP packet
    }

    close(sockfd);
    freeaddrinfo(res);
    return 0;
}

