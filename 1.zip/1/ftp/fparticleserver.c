#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
struct Student {
    char id[10];
    char name[100];
    char gender[10];
};
int main() {
    int sockfd, new_sock;
    struct sockaddr_in server_addr, new_addr;
    socklen_t addr_size;
    char buffer[10];
    struct Student student;
    FILE* file;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Error in socket");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(8080);
    server_addr.sin_addr.s_addr = INADDR_ANY;
    if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Error in binding");
        exit(1);
    }
    printf("Server is listening...\n");
    listen(sockfd, 10);
    addr_size = sizeof(new_addr);
    new_sock = accept(sockfd, (struct sockaddr*)&new_addr, &addr_size);
    recv(new_sock, buffer, 10, 0);
    printf("Student ID requested by client: %s\n",buffer);

    file = fopen("student.txt", "r");
    if (file == NULL) {
        perror("Error in opening file");
        exit(1);
    }
    int found = 0;
    while (fscanf(file, "%s %s %s", student.id, student.name, student.gender) != EOF) {
    if (strcmp(student.id, buffer) == 0) {
        send(new_sock, &student, sizeof(struct Student), 0);
        found = 1;
        break;
    }
}
    if (!found) {
        printf("Student ID not found.\n");
        send(new_sock, "NOT FOUND", sizeof("NOT FOUND"), 0);
    }
    fclose(file);
    close(new_sock);
    close(sockfd);
    return 0;
}
 
