#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
struct Student {
    char id[10];
    char name[100];
    char gender[10];
};
int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char student_id[10];
    struct Student student;
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Error in socket");
        exit(1);
    }
    printf("Client socket created.\n");
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(8080);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizseof(server_addr)) < 0) {
        perror("Error in connection");
        exit(1);
    }
    printf("Connected to the server.\n");
    printf("Enter the ID of the student to request: ");
    scanf("%s", student_id);
    send(client_socket, student_id, sizeof(student_id), 0);
    if (recv(client_socket, &student, sizeof(struct Student), 0) < 0) {
        perror("Error in receiving data");
    } else {
        if (strcmp(student.id, "NOT FOUND") == 0) {
            printf("Student not found.\n");
        } else {
            printf("Student Details:\n");
            printf("ID: %s\nName: %s\nGender: %s\n", student.id, student.name, student.gender);
        }
    }
    close(client_socket);
    return 0;
}

