//reading the particular students details from the file based on register number


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
struct Student {
    char regNo[10];
    char name[50];
    int age;
};

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);
    struct Student students[3];
    FILE *studentFile = fopen("file1.txt", "r");
    if (studentFile == NULL) {
        perror("Error in opening student file");
        exit(1);
    }
    for (int i = 0; i < 3; i++) {
        fscanf(studentFile,"%s %s %d", students[i].regNo, students[i].name, &students[i].age);
    }
    fclose(studentFile);
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        perror("Error in socket");
        exit(1);
    }
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345); // Port to listen on
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error in binding");
        exit(1);
    }
    if (listen(serverSocket, 10) == 0) {
        printf("Listening for clients...\n");
    } else {
        perror("Error in listen");
        exit(1);
    }
    clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
    if (clientSocket < 0) {
        perror("Error in accepting");
        exit(1);
    }
    char regNoReceived[10];
    recv(clientSocket, regNoReceived, sizeof(regNoReceived), 0);
    int studentIndex = -1;
    for (int i = 0; i < 3; i++) {
        if (strcmp(students[i].regNo, regNoReceived) == 0) {
            studentIndex = i;
            break;
        }
    }
    if (studentIndex != -1) {
        send(clientSocket, &students[studentIndex], sizeof(struct Student), 0);
    } else {
        printf("Student not found for registration number: %s\n", regNoReceived);
    }
    close(clientSocket);
    close(serverSocket);
    return 0;
}

