#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);
    char buffer[1024];
    FILE *file;
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        perror("Error in socket");
        exit(1);
    }
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345); // Port to listen on
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error in binding");
        exit(1);
    }
    if (listen(serverSocket, 10) == 0) {
        printf("Listening for clients...\n");
    } else {
        perror("Error in listen");
        exit(1);
    }
    clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
    if (clientSocket < 0) {
        perror("Error in accepting");
        exit(1);
    }
    file = fopen("received_file.txt", "w");
    if (file == NULL) {
        perror("Error in opening file");
        exit(1);
    }
    while (1) {
        ssize_t bytesReceived = recv(clientSocket, buffer, sizeof(buffer), 0);
        if (bytesReceived <= 0) {
            break;
        }
        fwrite(buffer, 1, bytesReceived, file);
    }
    
    printf("File received successfully.\n");
    fclose(file);
    close(clientSocket);
    close(serverSocket);
    return 0;
}

