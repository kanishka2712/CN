#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);
    char buffer[1024];
    FILE *file;

    // Create a socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        perror("Error in socket");
        exit(1);
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(1234); // Server port (you can choose a different port)
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error in binding");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(serverSocket, 5) == 0) {
        printf("Listening for clients...\n");
    } else {
        perror("Error in listen");
        exit(1);
    }

    // Accept a connection
    clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
    if (clientSocket < 0) {
        perror("Error in accepting");
        exit(1);
    }

    // Open the file to send
    file = fopen("example.txt", "rb"); // Change the filename as needed
    if (file == NULL) {
        perror("Error in opening file");
        exit(1);
    }

    // Read the file contents into a buffer
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    fread(buffer, 1, file_size, file);

    // Send the file contents in reverse order to the client
    for (long i = file_size - 1; i >= 0; i--) {
        send(clientSocket, &buffer[i], 1, 0);
    }

    fclose(file);

    // Close the connection
    close(clientSocket);
    close(serverSocket);
    return 0;
}

