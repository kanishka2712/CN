#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
struct Student {
    char regNo[10];
    char name[50];
    int age;
};
int main() {
    int clientSocket;
    struct sockaddr_in serverAddr;
    char regNoToSend[10];
    struct Student receivedStudent;
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket < 0) {
        perror("Error in socket");
        exit(1);
    }
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345); // Port of the server
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Server IP address
    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error in connection");
        exit(1);
    }
    printf("Enter student registration number: ");
    scanf("%s", regNoToSend);
    send(clientSocket, regNoToSend, sizeof(regNoToSend), 0);
    recv(clientSocket, &receivedStudent, sizeof(struct Student), 0);
    if (strcmp(receivedStudent.regNo, regNoToSend) == 0) {
        printf("Student Information:\n");
        printf("Registration Number: %s\n", receivedStudent.regNo);
        printf("Name: %s\n", receivedStudent.name);
        printf("Age: %d\n", receivedStudent.age);
    } else {
        printf("Student not found for registration number: %s\n", regNoToSend);
    }
    close(clientSocket);
    return 0;
}

