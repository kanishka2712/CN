#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>

int main() {
    int clientSocket;
    struct sockaddr_in serverAddr;
    char buffer[1024];
    FILE *file;
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket < 0) {
        perror("Error in socket");
        exit(1);
    }
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345); // Port of the server
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Server IP address
    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error in connection");
        exit(1);
    }
    file = fopen("filesend.txt", "r");
    if (file == NULL) {
        perror("Error in opening file");
        exit(1);
    }
    while (1) {
        ssize_t bytesRead = fread(buffer, 1, sizeof(buffer), file);
        if (bytesRead <= 0) {
            break;
        }
        send(clientSocket, buffer, bytesRead, 0);
    }    
    printf("File sent successfully.\n");
    fclose(file);
    close(clientSocket);
    return 0;
}

